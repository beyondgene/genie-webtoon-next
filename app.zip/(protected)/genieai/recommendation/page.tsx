'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport, type UIMessage } from 'ai';
import Link from 'next/link';

type Mode = 'idle' | 'choose' | 'genre' | 'taste';
type GenreSlug =
  | 'DRAMA'
  | 'ROMANCE'
  | 'FANTASY'
  | 'ACTION'
  | 'LIFE'
  | 'GAG'
  | 'SPORTS'
  | 'THRILLER'
  | 'HISTORICAL';

const GENRES: GenreSlug[] = [
  'DRAMA',
  'ROMANCE',
  'FANTASY',
  'ACTION',
  'LIFE',
  'GAG',
  'SPORTS',
  'THRILLER',
  'HISTORICAL',
];

type WebtoonItem = {
  id: number | string;
  title: string;
  genre: string;
  views?: number;
  thumbnail?: string;
  description?: string; // DB 오타 컬럼명 대응
};

const genreKo: Record<string, string> = {
  FANTASY: '판타지',
  ROMANCE: '로맨스',
  ACTION: '액션',
  DRAMA: '드라마',
  LIFE: '일상',
  GAG: '개그',
  SPORTS: '스포츠',
  THRILLER: '스릴러',
  HISTORICAL: '사극',
};

const detailUrlFor = (it: WebtoonItem) => `/webtoon/${it.id}`;

const makeAssistant = (text: string): UIMessage => ({
  id: crypto.randomUUID(),
  role: 'assistant',
  parts: [{ type: 'text', text }],
});

// 장르 클릭 시 서버에 보내지 않고, 로컬 말풍선을 추가하기 위한 helper
const makeUser = (text: string): UIMessage => ({
  id: crypto.randomUUID(),
  role: 'user',
  parts: [{ type: 'text', text }],
});

function getMessageText(m: UIMessage): string {
  const parts: any[] = (m as any)?.content ?? (m as any)?.parts ?? [];
  if (!Array.isArray(parts)) return '';
  return parts
    .map((p: any) => (p?.type === 'text' ? p.text : typeof p === 'string' ? p : ''))
    .join(' ')
    .trim();
}

const truncate = (s = '', n = 120) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s);

export default function RecommendationChatPage() {
  const [mode, setMode] = useState<Mode>('idle');

  // 추천 링크(바로가기) 목록
  const [linkItems, setLinkItems] = useState<WebtoonItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // 현재 선택된 장르(설명→바로가기 순서 제어)
  const currentGenreRef = useRef<GenreSlug | null>(null);

  // 순수 텍스트 채팅 (인사/안내/취향 추천용)
  const { messages, sendMessage, stop, setMessages } = useChat({
    transport: new DefaultChatTransport({ api: '/api/genieai/recommendation' }),
  });

  const sendUserText = (text: string) =>
    sendMessage({ role: 'user', parts: [{ type: 'text', text }] });

  // 첫 안내
  const booted = useRef(false);
  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    setMode('choose');
    setMessages((prev) => [
      ...prev,
      makeAssistant(`안녕하세요! 어떤 방식으로 추천해드릴까요?

1) 장르로 추천받기
2) 내 취향에 맞는 웹툰 추천받기

아래 버튼을 눌러 선택해주세요.`),
    ]);
  }, [setMessages]);

  const onClickChoose = (choice: 'genre' | 'taste') => {
    setMode(choice);
    setLinkItems([]);
    setApiError(null);

    if (choice === 'genre') {
      setMessages((prev) => [
        ...prev,
        makeAssistant(`원하는 장르를 선택해주세요:
${GENRES.join(', ')}`),
      ]);
    } else {
      setMessages((prev) => [...prev, makeAssistant('구독 내역을 분석해 추천을 생성할게요.')]);
      void loadTasteRecommendations(); // ← 새 함수 호출
    }
  };

  // 상세 설명을 가져오는 헬퍼 (description / discription 모두 대응)
  async function fetchDescriptionById(id: number | string) {
    // 1) /api/webtoon/[id]
    try {
      const r1 = await fetch(`/api/webtoon/${id}`, {
        headers: { accept: 'application/json' },
        cache: 'no-store',
      });
      if (r1.ok) {
        const j = await r1.json();
        return (
          j?.description ??
          j?.discription ?? // 오타 컬럼명 우선 대응
          j?.data?.description ??
          j?.data?.discription ??
          ''
        );
      }
    } catch {}

    // 2) /api/webtoons/[id] (다른 네이밍 대비)
    try {
      const r2 = await fetch(`/api/webtoons/${id}`, {
        headers: { accept: 'application/json' },
        cache: 'no-store',
      });
      if (r2.ok) {
        const j = await r2.json();
        return (
          j?.description ?? j?.discription ?? j?.data?.description ?? j?.data?.discription ?? ''
        );
      }
    } catch {}

    return '';
  }

  async function loadTasteRecommendations() {
    setLoading(true);
    setApiError(null);

    try {
      // 1) 추천 목록(JSON)
      const res = await fetch('/api/genieai/recommendation/for-me', {
        method: 'GET',
        headers: { accept: 'application/json' },
        cache: 'no-store',
      });

      if (!res.ok) {
        setApiError('추천 목록을 불러오지 못했습니다.');
        setLoading(false);
        return;
      }

      const rows = await res.json();
      const baseItems: WebtoonItem[] = (Array.isArray(rows) ? rows : []).map((r: any) => ({
        id: r.id ?? r.idx,
        title: r.title ?? r.webtoonName ?? '',
        genre: String(r.genre ?? '').toUpperCase(),
        views: r.views ? Number(r.views) : undefined,
        thumbnail: r.thumbnail ?? '',
        description: r.description ?? r.discription ?? '',
      }));

      // 2) 각 작품 상세에서 discription/description 취합
      const withDesc: WebtoonItem[] = await Promise.all(
        baseItems.map(async (it) => ({
          ...it,
          description: await fetchDescriptionById(it.id), // 상세 API에서 보정
        }))
      );

      // 3) 채팅창에 요약 설명(불릿) 먼저 뿌리고, 우측 카드 리스트는 linkItems로
      const bullets = withDesc
        .map(
          (it, i) =>
            `${i + 1}. **${it.title}** — ${truncate(it.description || '상세 설명을 불러오지 못했습니다.')}`
        )
        .join('\n');

      setMessages((prev) => [
        ...prev,
        makeAssistant('아래 작품들을 추천드려요 (구독 내역/장르/조회수 기반):'),
        makeAssistant(bullets),
      ]);

      // 사이드 추천 카드
      setLinkItems(withDesc);
    } catch (e) {
      console.error('[client] for-me fetch error:', e);
      setApiError('네트워크 오류로 추천 목록을 가져오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }
  // 장르 클릭: 서버에 메시지 전송❌ (중복 버블 방지) → 목록/상세 로드 → 설명 버블 추가 → 약간 딜레이 후 바로가기 패널
  const onClickGenre = async (g: GenreSlug) => {
    setMode('genre');
    setApiError(null);
    setLinkItems([]);
    currentGenreRef.current = g;

    // ✅ 서버 호출 대신 로컬에만 유저 말풍선 추가 (이걸로 중복 설명 버블 제거)
    setMessages((prev) => [...prev, makeUser(`장르: ${genreKo[g] ?? g}`)]);

    setLoading(true);
    try {
      // 1) 장르별 목록(JSON)
      const res = await fetch(`/api/genieai/recommendation/list-by-genre?genre=${g}`, {
        method: 'GET',
        headers: { accept: 'application/json' },
        cache: 'no-store',
      });
      if (!res.ok) {
        setApiError('추천 목록을 불러오지 못했습니다.');
        setLoading(false);
        return;
      }
      const rows = await res.json();

      const baseItems: WebtoonItem[] = (Array.isArray(rows) ? rows : []).map((r: any) => ({
        id: r.id ?? r.idx,
        title: r.title ?? r.webtoonName ?? '',
        genre: String(r.genre ?? '').toUpperCase(),
        views: r.views ? Number(r.views) : undefined,
        thumbnail: r.thumbnail ?? '',
        description: r.description ?? r.discription ?? '',
      }));

      // 2) 각 작품 상세에서 discription/description 취합
      const withDesc: WebtoonItem[] = await Promise.all(
        baseItems.map(async (it) => ({
          ...it,
          description: await fetchDescriptionById(it.id),
        }))
      );

      // 3) "설명 채팅"을 먼저 출력 (조회수 대신 설명 사용)
      const bullets = withDesc
        .map(
          (it, i) =>
            `${i + 1}. **${it.title}** — ${truncate(
              it.description || '상세 설명을 불러오지 못했습니다.'
            )}`
        )
        .join('\n');

      setMessages((prev) => [
        ...prev,
        makeAssistant(
          `${genreKo[g] ?? g} 장르의 추천 웹툰을 소개합니다:\n\n${bullets}\n\n아래 ‘바로가기’에서 상세페이지로 이동해 보세요!`
        ),
      ]);

      // 4) 설명 출력 후, 바로가기 패널은 살짝 늦게 노출
      setTimeout(() => {
        if (currentGenreRef.current === g) {
          setLinkItems(withDesc);
        }
        setLoading(false);
      }, 180);
    } catch (e) {
      console.error('[client] list-by-genre fetch error:', e);
      setApiError('네트워크 오류로 추천 목록을 가져오지 못했습니다.');
      setLoading(false);
    }
  };

  const GenreButtons = useMemo(
    () => (
      <div className="flex flex-wrap gap-2 my-2">
        {GENRES.map((g) => (
          <button
            key={g}
            onClick={() => onClickGenre(g)}
            className="px-4 py-2 rounded-full border shadow bg-white text-sm"
          >
            {g}
          </button>
        ))}
      </div>
    ),
    []
  );

  return (
    <main className="mx-auto max-w-3xl p-4">
      <header className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">지니AI · 작품 추천</h1>
        <Link href="/home" className="underline">
          홈으로
        </Link>
      </header>

      {mode === 'choose' && (
        <div className="flex gap-3 mb-6">
          <button
            onClick={() => onClickChoose('genre')}
            className="px-4 py-2 rounded-md shadow border bg-white"
          >
            1) 장르로 추천받기
          </button>
          <button
            onClick={() => onClickChoose('taste')}
            className="px-4 py-2 rounded-md shadow border bg-white"
          >
            2) 내 취향에 맞는 추천
          </button>
        </div>
      )}

      {mode === 'genre' && (
        <section className="mb-4">
          <p className="text-sm text-gray-600">* 아래 장르 버튼 중 하나를 선택하세요.</p>
          {GenreButtons}
        </section>
      )}

      {/* 채팅 메시지 */}
      <ul className="space-y-3">
        {messages.map((m) => {
          const text = getMessageText(m);
          if (!text) return null;
          return (
            <li key={m.id} className={m.role === 'user' ? 'text-right' : 'text-left'}>
              <div
                className={`inline-block max-w-[90%] whitespace-pre-wrap rounded-2xl px-3 py-2 shadow ${
                  m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-100'
                }`}
              >
                {text}
              </div>
            </li>
          );
        })}
      </ul>

      {/* 추천 링크 패널 */}
      <div className="mt-6">
        {loading && <div className="text-sm text-gray-500">추천 목록을 불러오는 중...</div>}
        {apiError && <div className="text-sm text-red-600">{apiError}</div>}

        {linkItems.length > 0 && (
          <div className="rounded-2xl border border-gray-200 bg-white p-4">
            <div className="text-sm font-semibold text-gray-700">추천 웹툰 바로가기</div>
            <ul className="mt-3 space-y-3">
              {linkItems.map((it) => (
                <li
                  key={it.id}
                  className="flex items-start justify-between gap-4 rounded-xl bg-gray-50 p-3"
                >
                  <div className="min-w-0">
                    <div className="truncate text-base font-medium">{it.title}</div>
                    <div className="mt-0.5 text-sm text-gray-500">
                      {(genreKo[it.genre] ?? it.genre) + ' · '} {truncate(it.description, 80)}
                    </div>
                  </div>
                  <Link
                    href={detailUrlFor(it)}
                    prefetch={false}
                    className="shrink-0 rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100"
                  >
                    바로가기
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* 스트리밍 제어(필요시) */}
      <div className="mt-4">
        <button type="button" onClick={stop} className="px-3 py-2 text-sm underline">
          정지
        </button>
      </div>
    </main>
  );
}
