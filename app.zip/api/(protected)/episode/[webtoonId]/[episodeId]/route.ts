import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/middlewares/auth';
import { getEpisodeDetailWithMeta } from '@/controllers/episode/detailController';
import { withErrorHandler } from '@/lib/middlewares/errorHandler';

function toImagesFromEpisode(episode: any): string[] {
  const a = episode?.contentUrls;
  const s = episode?.contentUrl;

  if (Array.isArray(a)) return a;

  if (typeof a === 'string') {
    try {
      const v = JSON.parse(a);
      if (Array.isArray(v)) return v;
    } catch {
      /* ignore */
    }
    return a
      .split(',')
      .map((x) => x.trim())
      .filter(Boolean);
  }

  if (typeof s === 'string' && s) return [s];

  return [];
}

async function GETHandler(
  req: NextRequest,
  { params }: { params: { webtoonId: string; episodeId: string } }
) {
  const sessionOrRes = await requireAuth(req);
  if (sessionOrRes instanceof NextResponse) return sessionOrRes;
  const userId = sessionOrRes.id as number;
  const webtoonId = parseInt(params.webtoonId, 10);
  const episodeId = parseInt(params.episodeId, 10);

  try {
    const data = await getEpisodeDetailWithMeta(userId, webtoonId, episodeId);
    const images = toImagesFromEpisode(data?.episode);
    return NextResponse.json({ ...data, images }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || '에피소드 상세 조회 중 오류' },
      { status: err.message === '해당 에피소드를 찾을 수 없습니다.' ? 404 : 500 }
    );
  }
}
export const GET = withErrorHandler(GETHandler);
