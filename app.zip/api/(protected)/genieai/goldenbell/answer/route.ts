import { withErrorHandler } from '@/lib/middlewares/errorHandler';
