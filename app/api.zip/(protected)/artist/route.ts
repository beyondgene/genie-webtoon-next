import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/middlewares/auth';
import { getArtistList, createArtist } from '@/controllers/artist/artistController';

export async function GET(req: NextRequest) {
  try {
    const sessionOrRes = await requireAdmin(req);
    if (sessionOrRes instanceof NextResponse) return sessionOrRes;

    const artists = await getArtistList();
    return NextResponse.json({ artists });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || '작가 목록 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const sessionOrRes = await requireAdmin(req);
    if (sessionOrRes instanceof NextResponse) return sessionOrRes;

    const body = await req.json();
    const artist = await createArtist(body, sessionOrRes.id as number);
    return NextResponse.json({ artist }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || '작가 생성 중 오류가 발생했습니다.' },
      { status: 400 }
    );
  }
}
